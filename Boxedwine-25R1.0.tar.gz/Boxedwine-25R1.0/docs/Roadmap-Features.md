### In Progress

1. Improve performance for Emscripten/Web build
2. Reduce memory usage

### Sometime in the distant future

1. Add support to mount ISO's
2. Gecko support
3. Steam Support
4. .NET and Java support
5. Copy/Paste support (DONE)
6. Add the ability to launch Dosbox for the few Windows games that use Dos installers.
7. Joystick support using SDL
